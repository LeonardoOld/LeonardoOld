import os
os.system("python starzed.pyc")
