-----
This is a custom bot with animation for Telegram. 
It was written using the pyrogram module.
After launching the file, you need to enter your telegram account details.
1) Phone number.
2) Entering the letter Y to confirm the number.
3) The code that came to telegram.
4) Password for two-step authorization, if you set it.
-----

Possible errors:
- Invalid code
- Wrong phone number
- A library with that name already exists.
